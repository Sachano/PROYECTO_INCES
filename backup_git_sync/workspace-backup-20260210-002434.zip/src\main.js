// Entrypoint wrapper — delega en main.jsx (efectos de montaje)
import './main.jsx'
