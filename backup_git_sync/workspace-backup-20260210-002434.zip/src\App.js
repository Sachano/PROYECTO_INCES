export { default } from './App.jsx'
